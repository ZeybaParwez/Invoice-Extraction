
Invoice Extraction - v1 2021-09-08 1:31pm
==============================

This dataset was exported via roboflow.ai on September 8, 2021 at 8:08 AM GMT

It includes 53 images.
Details-in-invoice are annotated in YOLO v5 PyTorch format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

The following augmentation was applied to create 3 versions of each source image:
* Equal probability of one of the following 90-degree rotations: none, clockwise, counter-clockwise
* Random rotation of between -4 and +4 degrees


